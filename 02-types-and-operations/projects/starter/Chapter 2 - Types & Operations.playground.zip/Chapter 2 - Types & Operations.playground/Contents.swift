
// MARK: Type conversion

var integer: Int = 100
var decimal: Double = 12.5
integer = Int(decimal)

// Operators with mixed types

let houelyRate: Double = 19.5
let hoursWorked: Int = 10
let totalCost: Double = houelyRate * Double(hoursWorked)

// Type inference

let typeInferedInt = 42
let typeInferedDouble = 3.14159

let wantADouble = 3
let actuallyDouble = Double(3)
let actuallyDouble2: Double = 3
let actuallyDouble3 = 3 as Double
let wantAdouble = 3.0

// MARK: Mini - exercises

// 1. Create a constant called 'age1' and set it equal to 42. Create a constant called 'age2' and set it equal to 21. Check using Option click that the type for both has been inferred correctly as Int.

let age1 = 42
let age2 = 21

// 2. Create a constant called 'avg1' and set it equal to the average of 'age1' and 'age2' using the naive operation (age1 + age2) / 2. Use Option - click to check the type and check the result of 'avg1'. why is it wrong?

let avg1 = (age1 + age2) / 2

// 3. Correct the mistake int the above exerise by converting 'age1' and 'age2' to type Double in the formula. Use Option-vlick to check the type and check the result of 'avg1'. Why is it now correct?

let avg2 = Double(age1 + age2) / 2

// Solution from book

let avg3 = (Double(age1) + Double(age2)) / 2

// MARK: Strings

// Characters and strings

let characterA: Character = "a"
let characterDog: Character = "🐶"
let stringDog = "Dog"

// Concatenation

var message = "Hello" + " my name is "
let name = "Matt"
message += name

let exclamationMark: Character = "!"
message += String(exclamationMark)

// Interpolation

message = "Hello my name is \(name)!"

let oneThird = 1.0 / 3.0
let oneThirdLongString = "One third is \(oneThird) as a decimal."

// Multi-line strings

let bigString = """
    You can have a string
    that contains multiple
    lines
    by
    doing this.
    """
print(bigString)

// MARK: Mini-exercises

// 1. Create a string constant called 'firstName' and initialize it to your first name. Also, create a string constant called 'lastName' and initialize it to your last name.

let firstName = "Alexander"
let lastName = "Grigorenko"

// 2. Create a string constant called 'fullName' by adding the 'firstName' and 'lastName' constants together, separated by a space.

let fullName = firstName + " " + lastName

// 3. Using inerpolation, create a string constant called 'myDetails' that uses the 'fullName' constant to create a string intoducing yourself. For example, my string would read: "Hello, my name is Matt Galloway.".

let myDetails = "Hello, my name is \(fullName)"

// MARK: Tuples

let coordinates: (Int, Int) = (2, 3)
let coordinates2 = (2, 3)
let coordinatesDoubles = (2.1, 3.5)
let coordinatesMixed = (2.1, 3)
let x1 = coordinates.0
let y1 = coordinates.1

let coordinatesNamed = (x: 2, y: 2)
let x2 = coordinatesNamed.x
let y2 = coordinatesNamed.y

let coordinates3D = (x: 2, y: 3, z: 1)
let (x3, y3, z3) = coordinates3D

let coordinates3D2 = (x: 2, y: 3, z: 1)
let x4 = coordinates3D2.x
let y4 = coordinates3D2.y
let z4 = coordinates3D2.z

let (x5, y5, _) = coordinates3D

// MARK: Mini-exercises

// 1. Declare a constant tuple that contains there Int values followed by a Double. Use this to represent a date (month, day, year) followed by an average temperature for that date.

var tuple = (month: 8.0, day: 12.0, year: 2023.0, averageTemperature: 15.0)

// 2. Change the tuple to name the constituent components. Give them names related to the data they contain: month, day, year and averageTemperature.


// 3. In one line, read the day and average temperature values into two contants. You'll need to employ the underscore to ignore the month and year.

let (_, day, _, averageTemperature) = tuple

// 4. Up until now, you've only seen constant tuples. But you can create variable tuples, too. Change the tuple you created in the exercises above to a variable by using var instead of let. Now change the average temperature to a new value.

tuple.averageTemperature = 14.2

// MARK: A whole lot of number types

let a: Int16 = 12
let b: UInt8 = 255
let c: Int32 = -100_000
let answer = Int(a) + Int(b) + Int(c)

// MARK: Type aliases

typealias Animal = String
let myPet: Animal = "Dog"

typealias Coordinates = (Int, Int)
let xy: Coordinates = (2, 4)


// MARK: Challenges

// MARK: 1: Coordinates

// Crate a constant called 'coordinates' and assign a tuple containing two and three to it.

let coordinates3 = (2, 3)

// MARK: 2: Named coordinate

// Create a constant called namedCoordinate with a 'row' and 'column' component.

let namedCoordinate = (row: 2, column: 3)

// MARK: 3: Which are valid?

// Which of the following are valid statements?

// let character: Character = "Dog"
let character: Character = "🐶"
let string: String = "Dog"
let string2: String = "🐶"

// MARK: 4: Does it compile?

let tuple2 = (day: 15, month: 8, year: 2015)
// let day = tuple2.Day

// MARK: 5: Find the error

// What is wrong with the following code?

/* let */ var name2 = "Matt"
name2 += " Galloway"

// MARK: 6: What is the type of value?

// What is the type of the constant named value?

let tuple3 = (100, 1.5, 10)
let value = tuple3.1

// MARK: 7: What is the value of month?

// What is the value of the constant named 'month'?

let tuple4 = (day: 15, month: 8, year: 2015)
let month = tuple4.month

// MARK: 8: What is the value of summary?

// What is the value of the constant named summary?

let number = 10
let multiplier = 5
let summary = "\(number) multiplied by \(multiplier) equals \(number * multiplier)"

// MARK: 9: Compute the value

// What is the sum of a and b, minus c?

let a2 = 4
let b2: Int32 = 100
let c2: UInt8 = 12
let sum = a2 + Int(b2) + Int(c2)

// MARK: 10: Different precision 𝜋s

// What is the numeric difference between Double.pi and Float.pi

let piDouble = Double.pi
let piFloat = Float.pi

let difference = Double.pi - Double(Float.pi)
